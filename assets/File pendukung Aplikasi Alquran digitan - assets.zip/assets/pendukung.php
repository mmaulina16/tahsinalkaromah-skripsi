Bissmillah
'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ'

Angka Arabic
$arabic_number = array('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩');